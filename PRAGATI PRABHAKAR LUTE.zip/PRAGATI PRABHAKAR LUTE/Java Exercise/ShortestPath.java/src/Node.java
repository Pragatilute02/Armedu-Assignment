import java.util.*;

class Node {
  String name;
  double gCost; 
  double hCost; 
  double fCost;
  List<Node> neighbors;
  Node parent;
  
  public Node(String name) {
    this.name = name;
    this.gCost = Double.POSITIVE_INFINITY;
    this.hCost = 0;
    this.fCost = Double.POSITIVE_INFINITY;
    this.neighbors = new ArrayList<>();
    this.parent = null;
  }
  public double distance(Node other) {
      return 1.0;
  }
}