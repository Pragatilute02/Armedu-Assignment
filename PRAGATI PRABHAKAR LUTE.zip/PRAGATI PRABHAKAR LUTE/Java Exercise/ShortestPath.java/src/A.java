import java.util.*;

public class A {

    public static void main(String[] args) {

        Graph graph = createGraph();

        Node source = getNodeByName(graph, "a");
        Node dest = getNodeByName(graph, "e");

        Set<Node> openSet = new HashSet<>();
        openSet.add(source);

        Set<Node> closedSet = new HashSet<>();

        while (!openSet.isEmpty()) {
            Node current = getMinFCostNode(openSet);

            if (current == dest) {
                printPath(source, current);
                return;
            }

            openSet.remove(current);
            closedSet.add(current);

            for (Node neighbor : current.neighbors) {
                if (closedSet.contains(neighbor)) continue;

                double tentativeGCost = current.gCost + current.distance(neighbor);

                if (!openSet.contains(neighbor) || tentativeGCost < neighbor.gCost) {
                    neighbor.gCost = tentativeGCost;
                    neighbor.hCost = heuristicCost(neighbor, dest);
                    neighbor.fCost = neighbor.gCost + neighbor.hCost;
                    neighbor.parent = current;
                    openSet.add(neighbor);
                }
            }
        }
    }

    static double heuristicCost(Node node, Node dest) {
        
        return 1.0;
    }

    static Node getMinFCostNode(Set<Node> openSet) {
        return openSet.stream()
                .min(Comparator.comparingDouble(node -> node.fCost))
                .orElse(null);
    }

    static void printPath(Node source, Node current) {
        if (current == source) {
            System.out.println(source.name);
            return;
        }

        printPath(source, current.parent);
        System.out.println(current.name);
    }

    static Graph createGraph() {
      
        Graph graph = new Graph();

        Node a = new Node("a");
        Node b = new Node("b");
        Node c = new Node("c");
        Node d = new Node("d");
        Node e = new Node("e");
        Node f = new Node("f");

        a.neighbors.addAll(Arrays.asList(b, d));
        b.neighbors.addAll(Arrays.asList(a, c, e));
        c.neighbors.addAll(Arrays.asList(b, f));
        d.neighbors.addAll(Arrays.asList(a, e));
        e.neighbors.addAll(Arrays.asList(b, d, f));
        f.neighbors.addAll(Arrays.asList(c, e));

        graph.nodes.addAll(Arrays.asList(a, b, c, d, e, f));

        return graph;
    }

    static Node getNodeByName(Graph graph, String nodeName) {
        return graph.nodes.stream()
                .filter(node -> node.name.equals(nodeName))
                .findFirst()
                .orElse(null);
    }
}