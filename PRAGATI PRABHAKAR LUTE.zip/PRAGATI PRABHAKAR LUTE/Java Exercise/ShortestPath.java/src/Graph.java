import java.util.*;

class Graph {
	List<Node> nodes;

    public Graph() {
        this.nodes = new ArrayList<>();
    }
	}