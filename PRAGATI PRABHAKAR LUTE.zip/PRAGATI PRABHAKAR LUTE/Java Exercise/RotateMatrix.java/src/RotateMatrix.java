public class RotateMatrix {

	  public static void rotate(int[][] mat) {
	    int n = mat.length;

	    
	    int layers = n / 2;

	    for(int layer = 0; layer < layers; layer++) {
	      int first = layer;
	      int last = n - 1 - layer;

	      for(int i = first; i < last; i++) {
	        int offset = i - first;

	        
	        int top = mat[first][i]; 

	      
	        mat[first][i] = mat[last-offset][first];

	       
	        mat[last-offset][first] = mat[last][last - offset]; 

	       
	        mat[last][last - offset] = mat[i][last];

	       
	        mat[i][last] = top; 
	      }
	    }
	  }

	  public static void main(String[] args) {
	    int[][] mat = {
	      {1, 2, 3},
	      {4, 5, 6}, 
	      {7, 8, 9}
	    };

	    rotate(mat);
	    for(int i=0; i<mat.length; i++) {
	        for(int j=0; j<mat[0].length; j++) {
	          System.out.print(mat[i][j] + " ");
	        }
	        System.out.println(); 
	      }
	  }

	}