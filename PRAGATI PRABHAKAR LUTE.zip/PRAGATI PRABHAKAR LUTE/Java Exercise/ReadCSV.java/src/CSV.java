import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CSV {

	  public static void main(String[] args) {

	    String file = "data.csv";

	    try {
	      BufferedReader br = new BufferedReader(new FileReader(file));

	      String line = br.readLine();

	      while ((line = br.readLine()) != null) {
	        
	        String[] values = line.split(",");
	        
	        String name = values[0]; 
	        int age = Integer.parseInt(values[1]);
	        double salary = Double.parseDouble(values[2]);

	        System.out.println("Name: " + name);
	        System.out.println("Age: " + age);  
	        System.out.println("Salar y: " + salary);
	      }

	      br.close();

	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	  }
	}
