import java.util.Random;

class MatrixMultiplication {

  public static int[][] naiveMultiply(int[][] A, int[][] B) {

    int n = A.length;
    int[][] C = new int[n][n];

    for(int i=0; i<n; i++) {
      for(int j=0; j<n; j++) {
        for(int k=0; k<n; k++) {
          C[i][j] += A[i][k] * B[k][j]; 
        }
      }
    }
    return C;
  }

  public static int[][] strassenMultiply(int[][] A, int[][] B) {
 
    if(A.length == 1)
      return new int[][]{{A[0][0] * B[0][0]}};
    
    int n = A.length;
    int[][] C = new int[n][n];
    int[][] A11 = new int[n/2][n/2]; 
    int[][] A12 = new int[n/2][n/2]; 
    int[][] A21 = new int[n/2][n/2];
    int[][] A22 = new int[n/2][n/2];

    int[][] B11 = new int[n/2][n/2];
    int[][] B12 = new int[n/2][n/2];
    int[][] B21 = new int[n/2][n/2]; 
    int[][] B22 = new int[n/2][n/2];

    int[][] P1 = strassenMultiply(A11, subtract(B12, B22));   
    int[][] P2 = strassenMultiply(add(A11, A12), B22);
    int[][] P3 = strassenMultiply(add(A21, A22), B11);
    int[][] P4 = strassenMultiply(A22, subtract(B21, B11));
    int[][] P5 = strassenMultiply(add(A11, A22), add(B11, B22));
    int[][] P6 = strassenMultiply(subtract(A12, A22), add(B21, B22));
    int[][] P7 = strassenMultiply(subtract(A11, A21), add(B11, B12));

    int[][] C11 = add(subtract(add(P5, P4), P2), P6);
    int[][] C12 = add(P1, P2); 
    int[][] C21 = add(P3, P4);
    int[][] C22 = subtract(add(P5, P1), P3);

    populate(C, C11, 0, 0);
    populate(C, C12, 0, n/2);
    populate(C, C21, n/2, 0);
    populate(C, C22, n/2, n/2);

    return C;
  }
  
  public static int[][] add(int[][] A, int[][] B) {
    int n = A.length;
    int[][] C = new int[n][n];
    for(int i=0; i<n; i++) {
      for(int j=0; j<n; j++) {
        C[i][j] = A[i][j] + B[i][j];
      }
    }
    return C;
  }

  public static int[][] subtract(int[][] A, int[][] B) {
    int n = A.length;
    int[][] C = new int[n][n];
    for(int i=0; i<n; i++) {
      for(int j=0; j<n; j++) {
        C[i][j] = A[i][j] - B[i][j];
      }
    }
    return C;
  }

  public static void populate(int[][] C, int[][] quad, int i, int j) {
    for(int x=0; x<quad.length; x++) {
      for(int y=0; y<quad.length; y++) {
        C[i+x][j+y] = quad[x][y];
      }
    }
  }

  public static void main(String[] args) {
    
    int n = 250; 
    Random rand = new Random();
    int[][] A = new int[n][n];
    int[][] B = new int[n][n];
    for(int i=0; i<n; i++) {
      for(int j=0; j<n; j++) {
        A[i][j] = rand.nextInt(100);
        B[i][j] = rand.nextInt(100);
      }
    }
    long start = System.currentTimeMillis();
    naiveMultiply(A, B); 
    long end = System.currentTimeMillis();
    System.out.println("Naive time: " + (end - start)/1000.0 + "s");

    start = System.currentTimeMillis();
    strassenMultiply(A, B);
    end = System.currentTimeMillis();
    System.out.println("Strassen's time: " + (end - start)/1000.0 + "s");

  }
}