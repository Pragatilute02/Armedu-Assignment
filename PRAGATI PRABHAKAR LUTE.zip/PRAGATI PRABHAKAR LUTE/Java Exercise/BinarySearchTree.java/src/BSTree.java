class BSTree {
	  Node root;

	  void insert(int data) {
	    Node newNode = new Node(data);

	    if(root == null) {
	      root = newNode; 
	    }
	    else {
	      Node temp = root;
	      while(true) {
	        if(data < temp.data) {
	          if(temp.left == null) {
	            temp.left = newNode;
	            break;
	          }
	          temp = temp.left;
	        } else {
	          if(temp.right == null) {
	            temp.right = newNode;
	            break;
	          } 
	          temp = temp.right;
	        }
	      }
	    }
	  }
	}