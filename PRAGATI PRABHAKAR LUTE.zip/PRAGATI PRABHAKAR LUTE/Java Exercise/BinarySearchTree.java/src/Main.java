class Main {
	  public static void main(String[] args) {
	    BSTree bst = new BSTree();

	    bst.insert(5); 
	    System.out.println(5);

	    bst.insert(3);
	    System.out.println(3);

	    bst.insert(8);
	    System.out.println(8);

	    bst.insert(2);
	    System.out.println(2);

	    bst.insert(4);
	    System.out.println(4);

	    bst.insert(11); 
	    System.out.println(11);
	  }
	}