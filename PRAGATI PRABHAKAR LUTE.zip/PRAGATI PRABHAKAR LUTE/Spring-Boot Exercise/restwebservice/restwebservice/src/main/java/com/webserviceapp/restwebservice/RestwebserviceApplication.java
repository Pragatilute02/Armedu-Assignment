package com.webserviceapp.restwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestwebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestwebserviceApplication.class, args);
		System.out.println("Application running...");
	}

}
