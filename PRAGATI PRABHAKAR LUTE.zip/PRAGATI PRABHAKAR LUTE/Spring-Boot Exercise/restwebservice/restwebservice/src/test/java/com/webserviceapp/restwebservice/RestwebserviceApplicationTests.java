package com.webserviceapp.restwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestwebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
